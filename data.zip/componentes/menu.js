class Intro extends Componente{}
class Menu extends Componente {}
class ComponenteEtiqueta extends Componente {}
